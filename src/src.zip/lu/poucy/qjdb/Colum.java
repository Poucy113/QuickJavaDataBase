package lu.poucy.qjdb;

public class Colum {

	private String name;
	
	public Colum(String string) {
		this.name = string;
	}
	
	public String getName() {return name;}
	public void setName(String name) {this.name = name;}

}
