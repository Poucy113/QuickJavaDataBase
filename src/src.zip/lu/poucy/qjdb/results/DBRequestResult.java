package lu.poucy.qjdb.results;

public interface DBRequestResult {}
