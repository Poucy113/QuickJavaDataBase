package lu.poucy.qjdb.results;

public class DBUpdateRequestResult implements DBRequestResult {}
